async function fetchTools(){
  const res = await fetch('/data/tools.json');
  return await res.json();
}

function matchesFilters(tool, q, cat, tier){
  const hay = (tool.name + ' ' + tool.short_description + ' ' + (tool.tags||[]).join(' ')).toLowerCase();
  const okQ = !q || hay.includes(q.toLowerCase());
  const okC = !cat || cat==='All' || tool.category===cat;
  const okT = !tier || tier==='All' || tool.pricing_tier===tier;
  return okQ && okC && okT;
}

function cardHTML(t){
  const badge = t.badge ? `<span class="badge">${t.badge}</span>` : '';
  const featured = t.is_featured ? `<span class="badge">Featured</span>` : '';
  const price = t.pricing_tier ? `<span class="badge">${t.pricing_tier}</span>` : '';
  const rating = t.rating ? `⭐ ${t.rating.toFixed(1)}` : '';
  return `<article class="card" data-slug="${t.slug}">
    <div class="badges">${featured}${badge}${price}</div>
    <h3>${t.name}</h3>
    <p class="small">${t.category}${t.subcategory? ' • '+t.subcategory:''} ${rating? ' • '+rating:''}</p>
    <p>${t.short_description}</p>
    <div class="cta">
      <a href="tool.html?slug=${encodeURIComponent(t.slug)}">Details</a>
      <a href="${t.affiliate_url || t.website_url}" rel="nofollow sponsored">Visit</a>
    </div>
  </article>`;
}

async function renderList(){
  const data = await fetchTools();
  const q = new URLSearchParams(location.search).get('q') || '';
  const cat = new URLSearchParams(location.search).get('cat') || 'All';
  const tier = new URLSearchParams(location.search).get('tier') || 'All';
  const listEl = document.querySelector('#list');
  const filtered = data.filter(t => matchesFilters(t, q, cat, tier));
  listEl.innerHTML = filtered.map(cardHTML).join('') || '<p>No results.</p>';
  // Update counts
  document.querySelector('#resultCount').textContent = filtered.length;
}

function bindFilters(){
  const q = document.querySelector('#q');
  const cat = document.querySelector('#cat');
  const tier = document.querySelector('#tier');
  [q, cat, tier].forEach(el => el && el.addEventListener('input', () => {
    const params = new URLSearchParams();
    if(q.value) params.set('q', q.value);
    if(cat.value && cat.value!=='All') params.set('cat', cat.value);
    if(tier.value && tier.value!=='All') params.set('tier', tier.value);
    history.replaceState(null, '', '?' + params.toString());
    renderList();
  }));
}

document.addEventListener('DOMContentLoaded', () => {
  bindFilters();
  renderList();
});