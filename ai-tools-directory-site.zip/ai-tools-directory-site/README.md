# AI Tools Directory — Free Static Site

**What you have here**
- 100% free, SEO-friendly directory: HTML/CSS/JS (no servers, no trials)
- Works on GitHub Pages, Cloudflare Pages, Netlify
- Built-in search & filters (client-side)
- Tool detail pages with JSON-LD (SoftwareApplication) for SEO
- robots.txt + sitemap.xml included

## Deploy (GitHub Pages — Free)
1. Create a GitHub account and a new public repo named `ai-tools-directory`.
2. Upload all files from this folder to the repo.
3. In the repo, go to **Settings → Pages → Source: Deploy from branch**. Choose `main` and `/ (root)`.
4. Wait 1–2 minutes — your site will be live at `https://<your-user>.github.io/ai-tools-directory/`.
5. Replace all instances of `https://example.github.io/` in `index.html`, `sitemap.xml` with your real URL.

## Update Data
- Edit `data/tools.json` to add/edit tools.
- Each tool needs a unique `slug`.
- Optional: add `affiliate_url` to monetize visits.

## SEO Tips
- Keep titles and meta descriptions unique.
- Add more categories in `index.html` and `categories.html`.
- Submit your sitemap URL in Google Search Console after publishing.
- Add content (a blog folder) for long-tail keywords.

## Local test
Open `index.html` in a modern browser using a local server to avoid CORS:
- Python: `python -m http.server 8000` then open `http://localhost:8000`
- Node: `npx http-server`

Updated: 2025-10-29T02:46:13Z